-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Sam 16 Mai 2015 à 09:39
-- Version du serveur: 5.5.20
-- Version de PHP: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `gestionhospital`
--
CREATE DATABASE `gestionhospital` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `gestionhospital`;

-- --------------------------------------------------------

--
-- Structure de la table `batiment`
--

CREATE TABLE IF NOT EXISTS `batiment` (
  `Numbatiment` int(8) NOT NULL DEFAULT '0',
  `Nombatiment` varchar(20) DEFAULT NULL,
  `CodeService` int(8) DEFAULT NULL,
  PRIMARY KEY (`Numbatiment`),
  KEY `CodeService` (`CodeService`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `batiment`
--

INSERT INTO `batiment` (`Numbatiment`, `Nombatiment`, `CodeService`) VALUES
(5000, 'Urgence', 4000),
(5001, 'ORL-Ophtamologie ', 4001),
(5002, 'Gynécologie ', 4002),
(5003, 'Médecin Interne', 4003),
(5004, ' Pédiatrie', 4004),
(5005, 'Chirurgie', 4005),
(5006, ' Kinésithérapie', 4006),
(5007, 'Pneumopathologie ', 4007),
(5008, 'Chirugie Natale', 4008);

-- --------------------------------------------------------

--
-- Structure de la table `hospitalisation`
--

CREATE TABLE IF NOT EXISTS `hospitalisation` (
  `NumSalle` int(8) DEFAULT NULL,
  `CodeMalade` int(8) DEFAULT NULL,
  `NumHospitalisation` int(8) NOT NULL DEFAULT '0',
  `Diagnostic` varchar(20) DEFAULT NULL,
  `DateHospitalisation` varchar(12) DEFAULT NULL,
  `NomMalade` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`NumHospitalisation`),
  KEY `CodeMalade` (`CodeMalade`),
  KEY `NumSalle` (`NumSalle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `hospitalisation`
--

INSERT INTO `hospitalisation` (`NumSalle`, `CodeMalade`, `NumHospitalisation`, `Diagnostic`, `DateHospitalisation`, `NomMalade`) VALUES
(8002, 2, 0, '7252000', '13/05/2015', NULL),
(8001, 5, 7003, 'Folie', NULL, NULL),
(8001, 2, 7005, 'troubles mentaux', NULL, NULL),
(8001, 4, 7009, 'Palu', NULL, NULL),
(8001, 3, 7010, 'MAL AU VENTRE', NULL, NULL),
(8001, 4, 7011, 'mal au ventre', NULL, NULL),
(8001, 1, 7012, 'mal au ventre', NULL, NULL),
(8001, 4, 7013, 'pleurs', '10/03/2015', NULL),
(8002, 5, 7014, 'pleurs', '10/03/2015', NULL),
(8001, 3, 7810, 'fievre', NULL, NULL),
(8001, 3, 7821, 'rires', NULL, NULL),
(8001, 4, 7825, 'ert', NULL, NULL),
(8002, 4, 70488, 'grippe', '24/02/2015', NULL),
(8002, 2, 72500, 'diarhee', '13/05/2015', NULL),
(8002, 9, 72501, 'reves', '15/05/2015', ''),
(8001, 9, 72503, 'cauchemars', '16/05/2015', 'sisqo'),
(8001, 9, 72504, 'cauchemars', '16/05/2015', 'joel');

-- --------------------------------------------------------

--
-- Structure de la table `infirmier`
--

CREATE TABLE IF NOT EXISTS `infirmier` (
  `CodeService` int(8) DEFAULT NULL,
  `CodeInfirmier` int(8) NOT NULL DEFAULT '0',
  `Numtel` int(8) DEFAULT NULL,
  `Salaire` int(8) DEFAULT NULL,
  `Horaire` time DEFAULT NULL,
  `NomInf` varchar(20) DEFAULT NULL,
  `PrenomInf` varchar(20) DEFAULT NULL,
  `AdresseInf` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CodeInfirmier`),
  KEY `CodeService` (`CodeService`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `infirmier`
--

INSERT INTO `infirmier` (`CodeService`, `CodeInfirmier`, `Numtel`, `Salaire`, `Horaire`, `NomInf`, `PrenomInf`, `AdresseInf`) VALUES
(4001, 2000, 695371782, 150000, '08:00:00', 'SIMO METAGNE', 'Eliane', 'Bepanda'),
(4002, 2001, 691150915, 150000, '18:00:00', 'DOUE DANKOUE', 'Stephene', 'Logpom'),
(4007, 2002, 693143690, 150000, '12:00:00', 'KENGHAJEU LONZI', 'Boris Kevin', 'Logbessou'),
(4000, 2003, 695371782, 150000, '18:00:00', 'NOUPA', 'Didier', 'Logbessou'),
(4001, 2005, 695371782, 150000, '12:00:00', 'KOUAKAM NONO', 'Christian', 'Yassa'),
(4001, 2006, 695371782, 150000, '08:00:00', 'KENOUYA TCHOUNGA', 'Armel Kevin', 'Bepanda'),
(4000, 2007, 695371782, 150000, '08:00:00', 'MOUTAPAM ESSE', 'Max Leonard', 'Bepanda'),
(4002, 2010, 676374564, 150000, '14:00:00', 'DOUANLA', 'JORDAN', 'ALLEMAGNE'),
(4004, 2012, 6744123, 50000, '06:00:00', 'FAMOU', 'VAMOUKE', 'YAOUNDE'),
(4005, 2013, 6723659, 20000, '12:00:00', 'MARVIN', 'GATES', 'USA'),
(4005, 2022, 45454, 455, '00:00:04', 'fddg', 'dfgd', 'dfg'),
(4005, 2023, 67637564, 675000, '08:00:00', 'wally', 'moi', 'yde');

-- --------------------------------------------------------

--
-- Structure de la table `malade`
--

CREATE TABLE IF NOT EXISTS `malade` (
  `CodeMalade` int(8) NOT NULL DEFAULT '0',
  `NomMalade` varchar(20) DEFAULT NULL,
  `PrenomMalade` varchar(20) DEFAULT NULL,
  `AdresseMalade` varchar(20) DEFAULT NULL,
  `Mutuelle` varchar(20) DEFAULT NULL,
  `Numtel` int(8) DEFAULT NULL,
  PRIMARY KEY (`CodeMalade`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `malade`
--

INSERT INTO `malade` (`CodeMalade`, `NomMalade`, `PrenomMalade`, `AdresseMalade`, `Mutuelle`, `Numtel`) VALUES
(1, 'simo metagne', 'elianne', 'douala logbessou', 'axa', 676374564),
(2, 'wally touko', 'toutcheu', 'bonaberi ', 'pme', 69878454),
(3, 'tchuati', 'hillary', 'bonasama ', 'bmf', 678456234),
(4, 'brooks', 'reine', 'bonamoussadi', 'axa', 0),
(5, 'zorro', 'roronoa', 'EAST BLUE', 'MUGIWARA', 0),
(6, 'benito', 'nzonlia', 'bonamoussadi', 'doctuerF', 67898),
(7, 'dariius', 'medie', 'douaal', 'axa', 0),
(8, 'benito', 'darius', 'douala', 'axa', 0),
(9, 'sisqo', 'barry', 'limoges', 'ctl', 0),
(10, 'joel', 'basso', 'angleterre', 'AXA', 0);

-- --------------------------------------------------------

--
-- Structure de la table `medecin`
--

CREATE TABLE IF NOT EXISTS `medecin` (
  `NumSpecial` int(8) DEFAULT NULL,
  `NomMedecin` varchar(12) DEFAULT NULL,
  `code` int(12) NOT NULL DEFAULT '0',
  `Adresse` varchar(20) DEFAULT NULL,
  `Numtel` int(8) DEFAULT NULL,
  `PrenomMedecin` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`code`),
  KEY `NumSpecial` (`NumSpecial`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `medecin`
--

INSERT INTO `medecin` (`NumSpecial`, `NomMedecin`, `code`, `Adresse`, `Numtel`, `PrenomMedecin`) VALUES
(2, 'NGONO NKE', 1001, 'Logpom', 697209992, 'Joachim Martial'),
(15, 'TCHUATI TCHO', 1002, 'Logpom', 691725312, 'Hillary Danka'),
(2, 'PEYO BASSO', 1003, 'japon', 67637454, 'FRANK AUDREY'),
(15, 'HADJIA RABBI', 1004, 'Newbell', 693173655, 'Ahmadou Tanko'),
(14, 'MBATKAM GASS', 1005, 'Logpom', 697875270, 'Serge Yannick'),
(9, 'KOUAM ', 1006, 'Ange Raphael', 699524821, 'Valaire'),
(3, 'FOGUE TSONO ', 1007, 'Bepanda', 699524821, 'Coralie'),
(13, 'EKANI ', 1008, 'Logbessou', 699821524, 'Louis Marie Pet'),
(10, 'BENITO ', 1009, 'Bepanda', 699524821, 'Nzonlia'),
(12, 'KAMSU SIMO ', 1010, 'Logbessou', 694727428, 'Patrick Arnold'),
(14, 'PEYO', 1016, 'DOUALA', 676374564, 'BASSO'),
(12, 'frank', 1023, 'limoge', 66669879, 'audrey'),
(3, 'AMANTANA', 1456, 'ROUEN', 67895561, 'MBALLA'),
(13, 'ZACH', 10010, 'PARIS', 6788645, 'POBA'),
(2, 'PEYO BASSO', 10016, 'Bonamoussadi', 676374764, 'Frank Audrey Em'),
(12, 'VAN ', 10021, 'ITALIE', 698124657, 'DARRYL TCHANGOM'),
(15, 'naruto', 10074, 'konoha', 678989, 'uzumaki'),
(14, 'joel', 10078, 'douala', 689776, 'basso'),
(15, 'wartuu', 10085, 'rome', 69887745, 'sensei'),
(15, 'wally', 10089, 'douala', 6789723, 'touko'),
(14, 'michel', 10099, 'douala', 6897723, 'ngono'),
(5, 'ONGHE', 10369, 'NORVEGE', 6789787, 'FRANK'),
(14, 'KENGHAJEU', 14789, 'DOUALA', 6789878, 'BORIS'),
(14, 'jean', 15688, 'limbe', 69798787, 'wally'),
(14, 'VAN ', 100231, 'ITALIE', 698124657, 'DARRYL TCHANGOM'),
(14, 'PELZER', 100235, 'ROME', 6789456, 'NYAAT'),
(14, 'NOUMO', 100248, 'LOGPOM', 67855632, 'CHOOUPO'),
(12, 'VARIALLE', 100258, 'EGYPTE', 678898, 'SORELLE');

-- --------------------------------------------------------

--
-- Structure de la table `salle`
--

CREATE TABLE IF NOT EXISTS `salle` (
  `NumSalle` int(8) NOT NULL DEFAULT '0',
  `Numbatiment` int(8) DEFAULT NULL,
  `CodeInfirmier` int(8) DEFAULT NULL,
  `NbreDeLit` int(8) DEFAULT NULL,
  `NumDeDebut` int(8) DEFAULT NULL,
  `NumDeFin` int(8) DEFAULT NULL,
  PRIMARY KEY (`NumSalle`),
  KEY `CodeInfirmier` (`CodeInfirmier`),
  KEY `Numbatiment` (`Numbatiment`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salle`
--

INSERT INTO `salle` (`NumSalle`, `Numbatiment`, `CodeInfirmier`, `NbreDeLit`, `NumDeDebut`, `NumDeFin`) VALUES
(8001, 5001, 2001, 5, 1, 9),
(8002, 5002, 2002, 10, 1, 5),
(8003, 5003, 2003, 4, 1, 3);

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
  `CodeService` int(8) NOT NULL DEFAULT '0',
  `code` int(12) DEFAULT NULL,
  `NomService` varchar(12) DEFAULT NULL,
  `Batiment` int(8) DEFAULT NULL,
  PRIMARY KEY (`CodeService`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `service`
--

INSERT INTO `service` (`CodeService`, `code`, `NomService`, `Batiment`) VALUES
(4000, 5000, 'Urgence', 1002),
(4001, 5001, 'ORL-Ophtamol', 1009),
(4002, 5002, 'Gynécologie', 1006),
(4003, 5003, 'Médecin Inte', 1006),
(4004, 5004, 'Pédiatrie', 1004),
(4005, 5005, 'Chirurgie ', 1002),
(4006, 5006, 'Kinésithérap', 1005),
(4007, 5007, ' Pneumopatho', 1008),
(4008, 5008, 'Psychiatrie', 1009),
(4009, 5009, 'Sociologie', 1010),
(4010, 5010, 'fraturologie', 1011);

-- --------------------------------------------------------

--
-- Structure de la table `specialite`
--

CREATE TABLE IF NOT EXISTS `specialite` (
  `NumSpecial` int(8) NOT NULL DEFAULT '0',
  `NomSpecial` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`NumSpecial`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `specialite`
--

INSERT INTO `specialite` (`NumSpecial`, `NomSpecial`) VALUES
(1, 'Pédiatrie'),
(2, 'Cardiologie'),
(3, 'Gastroentérologie'),
(4, 'Pneumologie'),
(5, 'Neurologie'),
(6, 'Infectiologie'),
(7, 'Rhumatologie'),
(8, 'Traumatologie et chi'),
(9, 'Gynécologie'),
(10, 'Ophtalmologie'),
(12, 'Cancérologie'),
(13, 'Pneumopathologie'),
(14, 'kinésithérapie'),
(15, 'Chirurgie');

-- --------------------------------------------------------

--
-- Structure de la table `suivre`
--

CREATE TABLE IF NOT EXISTS `suivre` (
  `code` int(8) NOT NULL DEFAULT '0',
  `CodeMalade` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`code`,`CodeMalade`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `suivre`
--

INSERT INTO `suivre` (`code`, `CodeMalade`) VALUES
(1001, 1),
(1003, 3),
(1004, 4),
(1006, 6),
(1007, 7),
(1008, 8),
(1009, 9),
(1010, 10),
(1012, 11),
(1013, 12),
(1014, 13);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `batiment`
--
ALTER TABLE `batiment`
  ADD CONSTRAINT `batiment_ibfk_1` FOREIGN KEY (`CodeService`) REFERENCES `service` (`CodeService`);

--
-- Contraintes pour la table `hospitalisation`
--
ALTER TABLE `hospitalisation`
  ADD CONSTRAINT `hospitalisation_ibfk_1` FOREIGN KEY (`CodeMalade`) REFERENCES `malade` (`CodeMalade`),
  ADD CONSTRAINT `hospitalisation_ibfk_2` FOREIGN KEY (`NumSalle`) REFERENCES `salle` (`NumSalle`);

--
-- Contraintes pour la table `infirmier`
--
ALTER TABLE `infirmier`
  ADD CONSTRAINT `infirmier_ibfk_1` FOREIGN KEY (`CodeService`) REFERENCES `service` (`CodeService`);

--
-- Contraintes pour la table `medecin`
--
ALTER TABLE `medecin`
  ADD CONSTRAINT `medecin_ibfk_1` FOREIGN KEY (`NumSpecial`) REFERENCES `specialite` (`NumSpecial`);

--
-- Contraintes pour la table `salle`
--
ALTER TABLE `salle`
  ADD CONSTRAINT `salle_ibfk_1` FOREIGN KEY (`CodeInfirmier`) REFERENCES `infirmier` (`CodeInfirmier`),
  ADD CONSTRAINT `salle_ibfk_2` FOREIGN KEY (`Numbatiment`) REFERENCES `batiment` (`Numbatiment`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
